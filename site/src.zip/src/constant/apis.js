// var API_SERVER = 'http://localhost:8090'
// var API_SERVER = 'http://www.straightwood.art:3002'
var LOCAL_SERVER = 'http://localhost:8090'
var API_SERVER = 'http://www.hanhuikrkr.com:8090'
//var API_SERVER = 'http://localhost:8090';

// var API_SERVER = 'https://webmooc.online'

export { API_SERVER,LOCAL_SERVER }
