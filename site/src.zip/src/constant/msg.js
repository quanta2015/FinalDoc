/*----  tips message define  ----*/
export const MSG_INP_ACC = '请输入账号!'
export const MSG_INP_PWD = '请输入密码！'

/*----  button message define  ----*/
export const MSG_INF_EDT = '編集'
export const MSG_INF_SAV = '保存'



